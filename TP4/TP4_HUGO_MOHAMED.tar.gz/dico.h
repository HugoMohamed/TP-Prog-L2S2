#ifndef DICO_H
#define DICO_H

#include "arbre.h"

typedef arbre dictionnaire

int existe(dictionnaire d, char * mot);

void affiche_dico(dictionnaire d);


#endif
