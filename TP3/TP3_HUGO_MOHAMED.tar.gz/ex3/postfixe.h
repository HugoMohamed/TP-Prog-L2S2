#ifndef POST_H
#define POST_H

#include "pile.h"
#include "allocation.h"

void erreur_exp();

int calcul_postfixe();

#endif
